/* Local XLSX adapter for offline use. JSZip 3.10.1 is bundled separately.
   Does not change the existing database or navigation code. */
(function(root){'use strict';
  if(!root.JSZip){console.warn('Offline Excel: JSZip not loaded');return;}
  const esc=s=>String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;');
  const col=i=>{let s='';for(i++;i;i=Math.floor((i-1)/26))s=String.fromCharCode(65+(i-1)%26)+s;return s;};
  const colIndex=s=>{let n=0;for(const ch of s.toUpperCase())n=n*26+ch.charCodeAt(0)-64;return n-1;};
  const doc=(xml)=>new DOMParser().parseFromString(xml,'application/xml');
  const localChildren=(el,name)=>Array.from(el?.getElementsByTagName('*')||[]).filter(n=>n.localName===name);
  const first=(el,name)=>localChildren(el,name)[0];
  const text=(el)=>el?.textContent||'';
  function aoa_to_sheet(rows){return {_rows:rows.map(row=>Array.from(row||[]))};}
  function book_new(){return {SheetNames:[],Sheets:{}};}
  function book_append_sheet(book,ws,name){
    let clean=String(name||'Sheet').replace(/[\\/?*:\[\]]/g,'_').slice(0,31)||'Sheet';
    if(book.SheetNames.includes(clean))clean=(clean.slice(0,27)+'_'+(book.SheetNames.length+1)).slice(0,31);
    book.SheetNames.push(clean);book.Sheets[clean]=ws;
  }
  function sheet_to_json(sheet,opts={}){
    const rows=sheet._rows||[], hdr=(rows[0]||[]).map((x,i)=>String(x||'__EMPTY'+i));
    const result=[];
    for(let i=1;i<rows.length;i++){
      const row=rows[i]||[];
      if(!row.some(x=>x!==null&&x!==undefined&&String(x).trim()!==''))continue;
      const obj={};
      hdr.forEach((h,j)=>{const v=row[j];if(v!==undefined&&v!==null&&v!=='')obj[h]=v;else if('defval'in opts)obj[h]=opts.defval;});
      result.push(obj);
    }
    return result;
  }
  function worksheetXml(rows){
    const rr=rows.map((row,ri)=>{
      const cells=(row||[]).map((v,ci)=>{
        if(v==null)return '';
        const cell=col(ci)+(ri+1);
        // Store as inline strings to preserve Persian digits, dates, leading zeros, and phone numbers.
        return '<c r="'+cell+'" t="inlineStr"><is><t xml:space="preserve">'+esc(v)+'</t></is></c>';
      }).join('');
      return '<row r="'+(ri+1)+'">'+cells+'</row>';
    }).join('');
    const lastCol=col(Math.max(0,...rows.map(r=>(r||[]).length-1)));
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'+
      '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><dimension ref="A1:'+lastCol+Math.max(1,rows.length)+'"/>'+
      '<sheetViews><sheetView workbookViewId="0" rightToLeft="1"/></sheetViews><sheetData>'+rr+'</sheetData></worksheet>';
  }
  function workbookXml(book){
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'+
      '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'+
      book.SheetNames.map((name,i)=>'<sheet name="'+esc(name)+'" sheetId="'+(i+1)+'" r:id="rId'+(i+1)+'"/>').join('')+'</sheets></workbook>';
  }
  function workbookRels(book){
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'+
      '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+
      book.SheetNames.map((n,i)=>'<Relationship Id="rId'+(i+1)+'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet'+(i+1)+'.xml"/>').join('')+
      '<Relationship Id="rId'+(book.SheetNames.length+1)+'" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>';
  }
  function contentTypes(book){
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'+
      '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'+
      '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'+
      '<Default Extension="xml" ContentType="application/xml"/>'+
      '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'+
      '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'+
      book.SheetNames.map((n,i)=>'<Override PartName="/xl/worksheets/sheet'+(i+1)+'.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>').join('')+'</Types>';
  }
  async function writeFile(book,filename){
    const zip=new root.JSZip();
    zip.file('[Content_Types].xml',contentTypes(book));
    zip.file('_rels/.rels','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
    zip.file('xl/workbook.xml',workbookXml(book));
    zip.file('xl/_rels/workbook.xml.rels',workbookRels(book));
    zip.file('xl/styles.xml','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="1"><font><sz val="11"/><name val="Arial"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellXfs></styleSheet>');
    book.SheetNames.forEach((name,i)=>zip.file('xl/worksheets/sheet'+(i+1)+'.xml',worksheetXml(book.Sheets[name]._rows||[])));
    const blob=await zip.generateAsync({type:'blob',compression:'DEFLATE',compressionOptions:{level:6},mimeType:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
    if(typeof root.payeshSaveBlob==='function' && root.PayeshAndroid){
      await root.payeshSaveBlob(blob,filename||'export.xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    }else{
      const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=filename||'export.xlsx';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),30000);
    }
    return blob;
  }
  function parseCsv(s){
    s=s.replace(/^\ufeff/,'');let delimiter=',';
    const head=s.split(/\r?\n/,1)[0]||'';
    if((head.match(/\t/g)||[]).length>(head.match(/,/g)||[]).length)delimiter='\t';
    else if((head.match(/;/g)||[]).length>(head.match(/,/g)||[]).length)delimiter=';';
    const rows=[],row=[];let value='',quoted=false;
    for(let i=0;i<s.length;i++){
      const ch=s[i];
      if(ch==='"'){if(quoted&&s[i+1]==='"'){value+='"';i++;}else quoted=!quoted;}
      else if(!quoted&&ch===delimiter){row.push(value);value='';}
      else if(!quoted&&(ch==='\n'||ch==='\r')){
        if(ch==='\r'&&s[i+1]==='\n')i++;
        row.push(value);rows.push(row.splice(0));value='';
      }else value+=ch;
    }
    if(value||row.length){row.push(value);rows.push(row);}
    return rows;
  }
  function readWorksheet(xml,shared){
    const d=doc(xml),out=[];
    for(const node of localChildren(d,'row')){
      const r=Math.max(0,(parseInt(node.getAttribute('r'))||out.length+1)-1),cells=[];
      for(const cell of Array.from(node.childNodes||[]).filter(x=>x.localName==='c')){
        const ref=cell.getAttribute('r')||'A1';const idx=colIndex((ref.match(/[A-Z]+/i)||['A'])[0]);
        const ty=cell.getAttribute('t');let value='';
        if(ty==='inlineStr')value=localChildren(first(cell,'is'),'t').map(text).join('');
        else if(ty==='s'){value=shared[parseInt(text(first(cell,'v')))||0]||'';}
        else if(ty==='b')value=text(first(cell,'v'))==='1';
        else value=text(first(cell,'v'));
        if(idx>=0&&idx<20000)cells[idx]=value;
      }
      if(r<200000)out[r]=cells;
    }
    return out;
  }
  async function readAsync(buffer){
    const bytes=buffer instanceof Uint8Array?buffer:new Uint8Array(buffer);
    if(bytes[0]!==0x50||bytes[1]!==0x4b){
      const b=new TextDecoder('utf-8').decode(bytes);
      const book=book_new();book_append_sheet(book,aoa_to_sheet(parseCsv(b)),'Sheet1');return book;
    }
    const zip=await root.JSZip.loadAsync(bytes);
    const entry=name=>zip.file(name)?.async('string');
    const shared=[];
    if(zip.file('xl/sharedStrings.xml')){
      const strings=doc(await entry('xl/sharedStrings.xml'));
      for(const si of localChildren(strings,'si'))shared.push(localChildren(si,'t').map(text).join(''));
    }
    const book=book_new();
    let sheetPaths=[];
    if(zip.file('xl/workbook.xml')){
      const workbookDoc=doc(await entry('xl/workbook.xml'));
      let relMap={};
      if(zip.file('xl/_rels/workbook.xml.rels')){
        const relDoc=doc(await entry('xl/_rels/workbook.xml.rels'));
        for(const rel of localChildren(relDoc,'Relationship')){
          let path=rel.getAttribute('Target')||'';
          path=path.startsWith('/')?path.slice(1):'xl/'+path.replace(/^\.\//,'');
          relMap[rel.getAttribute('Id')]=path;
        }
      }
      for(const [i,sheet] of localChildren(workbookDoc,'sheet').entries()){
        const rid=sheet.getAttribute('r:id')||sheet.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','id');
        sheetPaths.push({name:sheet.getAttribute('name')||'Sheet'+(i+1),path:relMap[rid]||'xl/worksheets/sheet'+(i+1)+'.xml'});
      }
    }
    if(!sheetPaths.length)sheetPaths=Object.keys(zip.files).filter(n=>/^xl\/worksheets\/sheet\d+\.xml$/.test(n)).sort().map((path,i)=>({name:'Sheet'+(i+1),path}));
    for(const sheet of sheetPaths){
      if(!zip.file(sheet.path))continue;
      book_append_sheet(book,aoa_to_sheet(readWorksheet(await entry(sheet.path),shared)),sheet.name);
    }
    if(!book.SheetNames.length)throw new Error('فایل اکسل معتبر نیست یا برگه‌ای ندارد');
    return book;
  }
  root.XLSX={utils:{book_new,book_append_sheet,aoa_to_sheet,sheet_to_json},writeFile,readAsync,version:'offline-pwa'};
})(window);
