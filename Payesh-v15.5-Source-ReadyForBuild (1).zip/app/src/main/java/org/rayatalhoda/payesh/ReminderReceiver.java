package org.rayatalhoda.payesh;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;

public final class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL="payesh_events";
    @Override public void onReceive(Context c,Intent intent) {
        if(intent==null)return;
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm==null)return;
        if(Build.VERSION.SDK_INT>=33&&c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel(CHANNEL,"یادآوری رویدادهای پایش",NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("یادآوری برنامه‌ها و رویدادها بدون اینترنت");
            nm.createNotificationChannel(ch);
        }
        final String title=intent.getStringExtra("title")==null?"رویداد":intent.getStringExtra("title");
        final String date=intent.getStringExtra("date")==null?"":intent.getStringExtra("date");
        final int slot=intent.getIntExtra("slot",0);
        final String prefix=slot==0?"یادآوری برنامه فردا":slot==1?"یادآوری امروز (اول)":"یادآوری امروز (دوم)";
        final String id=intent.getStringExtra("id");
        Intent open=new Intent(c,MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        open.putExtra("payesh_event_id",id);
        PendingIntent content=PendingIntent.getActivity(c,(id+slot).hashCode()&0x7fffffff,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification notification=new Notification.Builder(c,CHANNEL)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(prefix+": "+title)
                .setContentText(date+" — "+title)
                .setStyle(new Notification.BigTextStyle().bigText(date+" — "+title))
                .setContentIntent(content).setAutoCancel(true)
                .setColor(Color.rgb(13,148,136)).build();
        nm.notify((id+"_"+slot).hashCode(),notification);
    }
}
