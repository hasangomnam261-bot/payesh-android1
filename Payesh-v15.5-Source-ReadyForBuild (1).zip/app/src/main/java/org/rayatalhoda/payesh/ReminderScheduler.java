package org.rayatalhoda.payesh;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.HashSet;
import java.util.Set;

/** Stores reminders on-device and schedules them without remote services. */
public final class ReminderScheduler {
    private static final String PREF_NAME = "payesh_reminders_native";
    private static final String KEY_DATA = "events";
    private static final String KEY_CONFIG = "config";
    private static final String KEY_REQUEST_CODES = "request_codes";
    private ReminderScheduler() {}

    public static synchronized void update(Context c, String events, String config) {
        if (events == null || config == null || events.length() > 250000) return;
        try { new JSONArray(events); new JSONObject(config); } catch (Exception ex) { return; }
        c.getSharedPreferences(PREF_NAME,Context.MODE_PRIVATE).edit()
                .putString(KEY_DATA, events).putString(KEY_CONFIG,config).apply();
        reschedule(c);
    }
    public static synchronized void reschedule(Context c) {
        final Context context=c.getApplicationContext();
        AlarmManager manager=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        if(manager==null) return;
        SharedPreferences p=context.getSharedPreferences(PREF_NAME,Context.MODE_PRIVATE);
        Set<String> previous=p.getStringSet(KEY_REQUEST_CODES, new HashSet<>());
        for (String str : previous) {
            try {
                int requestCode=Integer.parseInt(str);
                PendingIntent old=makePendingIntent(context,requestCode,"","",0,"", "");
                manager.cancel(old);old.cancel();
            }catch(Exception ignore){}
        }
        Set<String> current=new HashSet<>();
        try {
            final JSONObject settings=new JSONObject(p.getString(KEY_CONFIG,"{}"));
            if(settings.optBoolean("enabled",true)) {
                JSONArray events=new JSONArray(p.getString(KEY_DATA,"[]"));
                long now=System.currentTimeMillis();
                for(int i=0;i<events.length();i++) {
                    JSONObject e=events.optJSONObject(i);if(e==null)continue;
                    JSONArray times=e.optJSONArray("times");if(times==null)continue;
                    for(int n=0;n<3&&n<times.length();n++) {
                        long when=times.optLong(n,0);
                        if(when<=now+15000 || when>now+370L*24*3600*1000)continue;
                        final int code=(e.optString("id",String.valueOf(i))+"/"+n).hashCode() & 0x7fffffff;
                        PendingIntent pi=makePendingIntent(context,code,e.optString("id"),e.optString("title"),n,e.optString("date"),e.optString("description"));
                        scheduleOne(manager,when,pi);
                        current.add(String.valueOf(code));
                    }
                }
            }
        }catch(Exception ignored){}
        p.edit().putStringSet(KEY_REQUEST_CODES,current).apply();
    }
    private static PendingIntent makePendingIntent(Context c,int code,String id,String title,int slot,String date,String description) {
        Intent intent=new Intent(c,ReminderReceiver.class);
        intent.setAction("org.rayatalhoda.payesh.REMIND."+code);
        intent.putExtra("id",id);intent.putExtra("title",title);intent.putExtra("slot",slot);
        intent.putExtra("date",date);intent.putExtra("description",description);
        return PendingIntent.getBroadcast(c,code,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private static void scheduleOne(AlarmManager mgr,long when,PendingIntent p) {
        try {
            if(Build.VERSION.SDK_INT>=31&&!mgr.canScheduleExactAlarms()) {
                mgr.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,p);
            } else {
                mgr.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,p);
            }
        } catch(SecurityException ex){mgr.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,p);}
    }
}
