package org.rayatalhoda.payesh;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Restores alarms after device reboot / system time change. */
public final class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent intent) {
        if(intent!=null) ReminderScheduler.reschedule(c);
    }
}
