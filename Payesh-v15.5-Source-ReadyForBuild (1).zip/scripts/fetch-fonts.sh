#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
FONTS="app/src/main/assets/fonts"
mkdir -p "$FONTS"
fetch(){
  local url="$1" target="$2"
  echo "Fetching $target"
  curl --fail --location --retry 4 --connect-timeout 20 --silent --show-error "$url" -o "$FONTS/$target.tmp"
  test "$(wc -c < "$FONTS/$target.tmp")" -gt 12000
  head -c 4 "$FONTS/$target.tmp" | grep -q 'wOF2' || { echo "Not a WOFF2 file: $target" >&2;exit 1; }
  mv "$FONTS/$target.tmp" "$FONTS/$target"
}
fetch 'https://raw.githubusercontent.com/rastikerdar/shabnam-font/master/dist/Shabnam.woff2' 'Shabnam.woff2'
fetch 'https://raw.githubusercontent.com/rastikerdar/vazirmatn/master/fonts/webfonts/Vazirmatn%5Bwght%5D.woff2' 'Vazirmatn.woff2'
fetch 'https://raw.githubusercontent.com/rastikerdar/sahel-font/master/dist/Sahel.woff2' 'Sahel.woff2'
fetch 'https://raw.githubusercontent.com/rastikerdar/samim-font/master/dist/Samim.woff2' 'Samim.woff2'
# All four fonts are licensed for redistribution under SIL OFL 1.1.
for repo in shabnam-font sahel-font samim-font; do
  curl --fail --location --retry 4 --silent --show-error "https://raw.githubusercontent.com/rastikerdar/$repo/master/LICENSE" -o "$FONTS/$repo-LICENSE.txt"
done
curl --fail --location --retry 4 --silent --show-error "https://raw.githubusercontent.com/rastikerdar/vazirmatn/master/OFL.txt" -o "$FONTS/vazirmatn-LICENSE.txt"
echo 'Four open-license local fonts ready (Yekan Bakh must be supplied by its licensed owner).'
